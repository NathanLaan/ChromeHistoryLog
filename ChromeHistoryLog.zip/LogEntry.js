//logentry


var LogEntry = function(){
	this.contents = "DEFAULT";

	function ToString(){
		return this.contents;
	}
	
}